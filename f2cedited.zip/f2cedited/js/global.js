
		   
		   $(document).ready(function(){
  $(".loaderbtn").click(function(){
		   $.mobile.loading( 'show', {text: "",	textVisible: true,	theme: 'z',	html: "<marquee behavior=1scroll'  scrollamount='10'><img src='images/f2clogo.png' alt='farm2customers.com'/></marquee>"});
		   })
});